<?php
$servername = getenv('DB_HOST') ?: 'db';
$username   = getenv('DB_USER') ?: 'wwwclient23';
$password   = getenv('DB_PASSWORD') ?: 'wwwclient23Creds';
$dbname     = getenv('DB_NAME') ?: '7009db';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /');
    exit;
}

$fullnamedata   = trim($_POST['fullname'] ?? '');
$suggestiondata = trim($_POST['suggestion'] ?? '');

if ($fullnamedata === '' || $suggestiondata === '') {
    header('Location: /');
    exit;
}

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    die("Database connection failed.");
}

$stmt = $conn->prepare("INSERT INTO suggestion (fullname, suggestion) VALUES (?, ?)");
if (!$stmt) {
    http_response_code(500);
    die("Query preparation failed.");
}

$stmt->bind_param("ss", $fullnamedata, $suggestiondata);
$stmt->execute();

$stmt->close();
$conn->close();

header('Location: /');
exit;
