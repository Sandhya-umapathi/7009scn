<?php
$servername = getenv('DB_HOST') ?: 'db';
$username   = getenv('DB_USER') ?: 'wwwclient23';
$password   = getenv('DB_PASSWORD') ?: 'wwwclient23Creds';
$dbname     = getenv('DB_NAME') ?: '7009db';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    die("Database connection failed.");
}

$stmt = $conn->prepare("SELECT fullname, suggestion FROM suggestion ORDER BY id DESC");
if (!$stmt) {
    http_response_code(500);
    die("Query preparation failed.");
}

$stmt->execute();
$stmt->store_result();
$stmt->bind_result($cuser, $csuggestion);

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Staff Suggestions</title>
</head>
<body>
  <div class="container">
    <h1>Staff Suggestions</h1>
    <h3>Share your constructive ideas to improve our workplace!</h3>

    <form action="action.php" method="post">
      <label for="fullname">Username:</label><br>
      <input type="text" id="fullname" name="fullname" required maxlength="64"><br>

      <label for="suggestion">Suggestion:</label><br>
      <textarea id="suggestion" name="suggestion" rows="5" required></textarea><br><br>

      <button type="submit">Submit Suggestion</button>
    </form>

    <p>Submit your suggestions to help us create a better working environment.</p>

    <table>
      <tr>
        <th>User</th>
        <th>Suggestion</th>
      </tr>

      <?php while ($stmt->fetch()): ?>
        <tr>
          <td><?= e($cuser) ?></td>
          <td><?= e($csuggestion) ?></td>
        </tr>
      <?php endwhile; ?>

    </table>
  </div>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
